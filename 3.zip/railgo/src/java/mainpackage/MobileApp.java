/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mainpackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * REST Web Service
 *
 * @author visha
 */
@Path("generic")
public class MobileApp {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of MobileApp
     */
    public MobileApp() {
    }

    /**
     * Retrieves representation of an instance of mainpackage.MobileApp
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getJson() {
        //TODO return proper representation object
        throw new UnsupportedOperationException();
    }

    /**
     * PUT method for updating or creating an instance of MobileApp
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public void putJson(String content) {
    }
    
    
     @GET        // login

    @Path("login&{id}&{pass}")
    @Produces("application/json")
    public String getXml2(@PathParam("id") String emlID, @PathParam("pass") String password) {
        long time = System.currentTimeMillis();
        int user_id;
        String email;
        JSONObject obj = new JSONObject();
        obj.accumulate("Status", "Error");
        obj.accumulate("Epoch Time", time);
        try {

            Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam4", "anypw");
            Statement stm = con.createStatement();

            String sql = "select * from users where email=" + "'" + emlID + "' and password=" + "'" + password + "'";
            ResultSet rs = stm.executeQuery(sql);

            if (rs.next() == false) {
                obj.accumulate("Message", "Login failed");
            } else {
                obj.clear();
                obj.accumulate("Status", "OK");
                obj.accumulate("Epoch Time", time);
                obj.accumulate("Message", "Successfully Login");

                user_id=rs.getInt("USERID");
                emlID = rs.getString("EMAIL");
                obj.accumulate("USER_ID",user_id);
                System.out.println(user_id);
                obj.accumulate("EMAIL_ID",emlID);
            }

            con.close();

        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return obj.toString();

    }

  //Registration
    @GET
    @Path("signup&{username}&{usertype}&{email}&{contactnumber}&{password}")
    @Produces("application/json")
    public String getJson1(@PathParam("username") String username, @PathParam("usertype") String usertype, @PathParam("email") String email,
            @PathParam("password") String pass, @PathParam("contactnumber") String contactnumber) throws SQLException, ClassNotFoundException {
        int userid = 0;
        String email_id = null;
        int number =0;
         long time = System.currentTimeMillis();
        JSONObject jsondata = new JSONObject();
        try {
            
             Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam4", "anypw");
            Statement stm = con.createStatement();
            try {
                ResultSet rs2 = stm.executeQuery("select email,userid from users where exists(select email from users where email='" + email + "')");
                if (rs2.next() == false) {
                    ResultSet rs = stm.executeQuery("SELECT USERID,EMAIL FROM USERS order by USERID DESC");
                    rs.next();

                    userid = rs.getInt("USERID");
                    email_id = rs.getString("EMAIL");
                    System.out.println("USERID OF THE USER IS " + userid);
                    ++userid;
                    number = stm.executeUpdate("INSERT INTO USERS VALUES(" + userid + "," + "'" + username + "'" + "," + "'" + email + "'" + "," + "'" + contactnumber + "'" + "," + "'" + pass + "'" + "," + "'" + usertype + "'" + ")");
                    System.out.println("total inserted rows" + number);
                } else {

                    jsondata.accumulate("STATUS", "WRONG");
                   jsondata.accumulate("Epoch Time", time);
                    jsondata.accumulate("Message", "Email is already Register");

                }
            } catch (SQLException sq) {


                System.out.println(sq.getMessage());
                userid = 100;
            }

            if (number == 1) {
                jsondata.accumulate("STATUS", "OK");
                 jsondata.accumulate("Epoch Time", time);
                jsondata.accumulate("Active", true);
                jsondata.accumulate("User_id", userid);
                jsondata.accumulate("Message", "You are successfully Register");

            } else if (number == 0) {

            }

            stm.close();
        } catch (SQLException ex) {

            System.out.println(ex.getMessage());
            jsondata.accumulate("STATUS", "ERROR");
            jsondata.accumulate("Epoch Time", time);
            jsondata.accumulate("MESSAGE", "DATABASE CONNECTIVITY ERROR");
        }
        return jsondata.toString();
    }
  
    
    // VIEW BOOKING
    
    @GET
    @Path("Bookings&{id}")
    @Produces("application/json")
    public String getXML1(@PathParam("id") int userId) {
        JSONObject  booking = new JSONObject();
        booking.accumulate("Status","Error");
        booking.accumulate("Message","User ID does not exists");
         JSONObject jsonobject=new JSONObject();
        
         try {
             Class.forName("oracle.jdbc.OracleDriver");
             Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam4", "anypw");
             java.sql.Statement stm = con.createStatement();
             String sql = "select * from booking where usersuserId = "+userId;
            
             JSONArray jsonarray=new JSONArray();
             ResultSet rs = stm.executeQuery(sql);
             
             
             booking.clear();
                   jsonobject.accumulate("Status","OK");
                 
                int bookingid, coachnumber, numberofpassengers, usersuserid, stationstationid, traintrainnumber;
                String email, fromstation, tostation, bookingdate,status, passengername;
                 while(rs.next()){
                    bookingid = rs.getInt("BOOKINGID");
                    email = rs.getString("EMAIL");
                    fromstation = rs.getString("FROMSTATION");
                    tostation = rs.getString("TOSTATION");
                    bookingdate = rs. getString("BOOKINGDATE");
                    coachnumber = rs. getInt("COACHNUMBER");
                    numberofpassengers = rs. getInt("NUMBEROFPASSENGERS");
                    
                    usersuserid = rs. getInt("USERSUSERID");
                    stationstationid = rs. getInt("STATIONSTATIONID");
                    traintrainnumber = rs. getInt("TRAINTRAINNUMBER");
                    status = rs. getString("STATUS");
                    passengername = rs.getString("PASSENGERNAME");
                   
                    
                   
                    booking.accumulate("bookingid", bookingid);
                    booking.accumulate("Email", email);
                    booking.accumulate("FromStation", fromstation);
                    booking.accumulate("ToStation", tostation);
                    booking.accumulate("BookingDate", bookingdate);
                    booking.accumulate("Coachnumber", coachnumber);
                    booking.accumulate("NumberOfPassengers", numberofpassengers);
                    
                    booking.accumulate("UserId", usersuserid);
                    booking.accumulate("StationId", stationstationid);
                    booking.accumulate("TrainNumber", traintrainnumber);
                    booking.accumulate("status", status);
                    booking.accumulate("passengerNames", passengername);
                   jsonarray.add(booking);
                    booking.clear();
             }   
                 jsonobject.accumulate("DATA",jsonarray);
               rs.close();
               stm.close();
               con.close();
         } catch (ClassNotFoundException | SQLException e) {
             System.out.println(e.getMessage());
         }        
        return jsonobject.toString();
    } 
    
 



    
    //get station
    

     @GET
    @Path("station")
    @Produces("application/json")
    public String getXml(@PathParam("id") int stationID) throws SQLException {

        long time = System.currentTimeMillis();
        JSONObject SingleStation = new JSONObject();

//        SingleStation.accumulate("Status", "Error");
//        SingleStation.accumulate("EpochTime", time);
//        SingleStation.accumulate("Message", "Station id not exists");
         JSONArray Data = new JSONArray();
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam4", "anypw");
            Statement stm = con.createStatement();

            String sql = "select * from station";
            ResultSet rs = stm.executeQuery(sql);

            int stationid;
            String name, location;
            SingleStation.accumulate("Status", "Ok");
            SingleStation.accumulate("EpochTime", time);

            
            while (rs.next()) {
//                SingleStation.clear();

                JSONObject station = new JSONObject();


                stationid = rs.getInt("stationid");
                name = rs.getString("name");
                location = rs.getString("location");

               
                
                
                station.accumulate("stationId", stationid);
                station.accumulate("name", name);
                station.accumulate("location", location);
                Data.add(station);
                station.clear();

              

            }  rs.close();
                stm.close();
                con.close();
            SingleStation.accumulate("DATA",Data);

        } catch (ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return SingleStation.toString();
    }

    @PUT
    @Consumes(MediaType.APPLICATION_XML)
    public void putXml(String content) {
    }
    
    
    
    
   // view user profile
    @GET
    @Path("user_Profile&{email}")
    @Produces("application/json")
    public String getXml3(@PathParam("email") String email) {
        long time = System.currentTimeMillis();
        JSONObject obj = new JSONObject();
            int USERID;
                String USERTYPE, contactNUMBER;
                String EMAILID, userNAME, PASSWORD;

        JSONArray Jarray = new JSONArray();
        try {

            Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam4", "anypw");
            Statement stm = con.createStatement();
            String sql = "select * from users where email=" + "'" + email + "'";

            ResultSet rs = stm.executeQuery(sql);
            
               
                    rs.next();
                    obj.accumulate("Status", "OK");
                    obj.accumulate("Epoch Time", time);
                    USERID = rs.getInt("USERID");
                    userNAME = rs.getString("USERNAME");

                    USERTYPE = rs.getString("USERTYPE");
                    EMAILID = rs.getString("EMAIL");

                    PASSWORD = rs.getString("PASSWORD");

                    contactNUMBER = rs.getString("CONTACTNUMBER");

                    obj.accumulate("USERID", USERID);
                    obj.accumulate("USERNAME", userNAME);

                    obj.accumulate("USERTYPE", USERTYPE);
                    obj.accumulate("EMAIL", EMAILID);
                    obj.accumulate("PASSWORD", PASSWORD);
                    obj.accumulate("CONTACTNUMBER", contactNUMBER);
               
            

            rs.close();
            stm.close();
            con.close();

        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return obj.toString();

    }
    
    


   

//DO BOOKING
   
   @GET
    @Path("Booking&{email}&{fromstation}&{tostation}&{bookingdate}&{coachnumber}&{numberofpassengers}&{seatnumber}&{usersuserid}&{stationstationid}&{traintrainnumber}&{status}")
    @Produces("application/json")
    public String getJson2( @PathParam("email") String email, @PathParam("fromstation") String fromstation, @PathParam("tostation") String tostation, @PathParam("bookingdate") String bookingdate, @PathParam("coachnumber") int coachnumber,  @PathParam("numberofpassengers") int numberofpassengers,  @PathParam("seatnumber") int seatnumber,  @PathParam("usersuserid") int usersuserid,  @PathParam("stationstationid") int stationstationid,  @PathParam("traintrainnumber") int traintrainnumber, @PathParam("status") String status )
         throws SQLException, ClassNotFoundException {
        int bookingid = 0;
        int number =0;
         long time = System.currentTimeMillis();
        JSONObject jsondata = new JSONObject();
        try {
            
             Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam4", "anypw");
            Statement stm = con.createStatement();
            try {
                
                 
                    ResultSet rs = stm.executeQuery("SELECT BOOKINGID FROM BOOKING order by BOOKINGID DESC");
                    rs.next();

                    bookingid = rs.getInt("BOOKINGID");
          
                    System.out.println("BOOKINGID OF THE USER IS " + bookingid);
                    ++bookingid;
                    number = stm.executeUpdate("INSERT INTO BOOKING VALUES(" + bookingid + "," + "'" + email + "'" + "," + "'" + fromstation + "'" + "," + "'" + tostation + "'" + "," + "'" + bookingdate + "'" + "," + "" + coachnumber + "" + "," + "" + numberofpassengers + "" + "," + "" + seatnumber + "" + "," + "" + usersuserid + "" + "," + "" + stationstationid + "" + "," + "" + traintrainnumber + "" + "," + "'" + status + "'" + ")");
                    System.out.println("total inserted rows" + number);
                 if (rs.next() == false) {

                    jsondata.accumulate("STATUS", "WRONG");
                   jsondata.accumulate("Epoch Time", time);
                    jsondata.accumulate("Message", "wrong information entered");

                }
            } catch (SQLException sq) {


                System.out.println(sq.getMessage());
                bookingid = 100;
            }

            if (number == 1) {
                jsondata.accumulate("STATUS", "OK");
                 jsondata.accumulate("Epoch Time", time);
                jsondata.accumulate("Active", true);
                jsondata.accumulate("User_id", bookingid);
                jsondata.accumulate("Message", "Booking Done");

            } else if (number == 0) {

            }

            stm.close();
        } catch (SQLException ex) {

            System.out.println(ex.getMessage());
            jsondata.accumulate("STATUS", "ERROR");
            jsondata.accumulate("Epoch Time", time);
            jsondata.accumulate("MESSAGE", "DATABASE CONNECTIVITY ERROR");
        }
        return jsondata.toString();
    } 
    
    
    //cancel BOOKING
      @GET
    @Path("Booking&{id}")
    @Produces("application/json")
    public String getJson3( @PathParam("id") int id )
         throws SQLException, ClassNotFoundException {
        int bookingid ;
        int number =0;
         long time = System.currentTimeMillis();
        JSONObject jsondata = new JSONObject();
        try {
            
             Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam4", "anypw");
            Statement stm = con.createStatement();
            try {
                
                 
                    ResultSet rs = stm.executeQuery("SELECT * FROM BOOKING where BOOKINGID="+ "" + id + "");
                    rs.next();

                    bookingid = rs.getInt("BOOKINGID");
          
                    
                    number = stm.executeUpdate("UPDATE  BOOKING set status='Cancel' where BOOKINGID="+ "" + id + "");
                    System.out.println("total inserted rows" + number);
                 if (rs.next() == false) {

                    jsondata.accumulate("STATUS", "WRONG");
                   jsondata.accumulate("Epoch Time", time);
                    jsondata.accumulate("Message", "wrong Booking id");

                }
            } catch (SQLException sq) {


                System.out.println(sq.getMessage());
                bookingid = 100;
            }

            if (number == 1) {
                jsondata.accumulate("STATUS", "OK");
                 jsondata.accumulate("Epoch Time", time);
                jsondata.accumulate("Active", true);
                jsondata.accumulate("Booking_id", bookingid);
                jsondata.accumulate("Message", "Booking Cancel");

            } else if (number == 0) {

            }

            stm.close();
        } catch (SQLException ex) {

            System.out.println(ex.getMessage());
            jsondata.accumulate("STATUS", "ERROR");
            jsondata.accumulate("Epoch Time", time);
            jsondata.accumulate("MESSAGE", "DATABASE CONNECTIVITY ERROR");
        }
        return jsondata.toString();
    } 
    
     //searchTrain
    

     @GET
    @Path("searchTrain&{fromStation}&{toStation}")
    @Produces("application/json")
    public String getXml(@PathParam("fromStation") String fromStation,@PathParam("toStation") String toStation) throws SQLException {

        long time = System.currentTimeMillis();
       
        JSONObject SingleStation = new JSONObject();

        try {
            Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam4", "anypw");
            Statement stm = con.createStatement();

            System.out.println("select * from train where DEPARTURESTATION='"+ fromStation + "' and DESTINATIONSTATION='"+toStation+"'");
            String sql = "select * from train where DEPARTURESTATION='"+ fromStation + "' and DESTINATIONSTATION='"+toStation+"'";
            ResultSet rs = stm.executeQuery(sql);

            int trainid,available_seats;
            String name, location, departureStation, destinationStation, departureTime, destinationTime;

            SingleStation.accumulate("Status", "Ok");
                SingleStation.accumulate("EpochTime", time);
                JSONObject jsonobject=new  JSONObject();
                JSONArray jsonarray=new JSONArray();
            while (rs.next()) {
                SingleStation.clear();
                trainid = rs.getInt("trainnumber");
                name = rs.getString("trainname");
               available_seats=rs.getInt("AVAILABLESEATS");
               departureStation = rs.getString("DEPARTURESTATION");
               destinationStation = rs.getString("DESTINATIONSTATION");
               departureTime = rs.getString("DEPARTURETIME");
               destinationTime = rs.getString("DESTINATIONTIME");
               
               jsonobject.accumulate("trainNumber", trainid);
                jsonobject.accumulate("name", name);
                
                jsonobject.accumulate("departureStation",departureStation);
                jsonobject.accumulate("destinationStation",destinationStation);
                jsonobject.accumulate("departureTime",departureTime);
                jsonobject.accumulate("destinationTime",destinationTime);
                jsonobject.accumulate("availableSeats",available_seats);
                
                jsonarray.add(jsonobject);
                jsonobject.clear();
               
           
            }SingleStation.accumulate("DATA",jsonarray);
                rs.close();
                stm.close();
                con.close();


        } catch (ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (SQLException ex) {
            
        SingleStation.accumulate("Status", "Error");
        SingleStation.accumulate("EpochTime", time);
        SingleStation.accumulate("Message", "no train");
            System.out.println(ex.getMessage());
        }

        return SingleStation.toString();
    }
    
    // DO BOOKING
     @GET
    @Path("booking&{email}&{fromstation}&{tostation}&{bookingdate}&{coachnumber}&{numberofpassengers}&{usersuserid}&{stationstationid}&{traintrainnumber}&{status}&{passengername}")
    @Produces("application/json")
    public String getJson3(@PathParam("email") String email, @PathParam("fromstation") String fromstation, @PathParam("tostation") String tostation, @PathParam("bookingdate") String bookingdate, @PathParam("coachnumber") int coachnumber, @PathParam("numberofpassengers") int numberofpassengers, @PathParam("seatnumber") int seatnumber, @PathParam("usersuserid") int usersuserid, @PathParam("stationstationid") int stationstationid, @PathParam("traintrainnumber") int traintrainnumber, @PathParam("status") String status,@PathParam("passengername") String passengername)
            throws SQLException, ClassNotFoundException {
        int bookingid = 0;
        int number = 0;
        long time = System.currentTimeMillis();
        JSONObject jsondata = new JSONObject();

        try {
            Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam4", "anypw");
            Statement stm = con.createStatement();
            try {
                ResultSet rs = stm.executeQuery("SELECT BOOKINGID FROM BOOKING ORDER BY BOOKINGID DESC");
                rs.next();
                bookingid = rs.getInt("BOOKINGID");
                System.out.println("BOOKINGID OF THE BOOKING IS " + bookingid);
                ++bookingid;
            } catch (SQLException sq) {

                System.out.println(sq.getMessage());
                bookingid = 1000;
            }
            System.out.println("INSERT INTO BOOKING VALUES(" + bookingid + "," + "'" + email + "'" + "," + "'" + fromstation + "'" + "," + "'" + tostation + "'" + "," + "'" + bookingdate + "'" + "," + "" + coachnumber + "" + "," + "" + numberofpassengers + "" + ","+ "" + usersuserid + "" + "," + "" + stationstationid + "" + "," + "" + traintrainnumber + "" + "," + "'" + status + "'" + "," + "'" + passengername + "'" + ")");
            number = stm.executeUpdate("INSERT INTO BOOKING VALUES(" + bookingid + "," + "'" + email + "'" + "," + "'" + fromstation + "'" + "," + "'" + tostation + "'" + "," + "'" + bookingdate + "'" + "," + "" + coachnumber + "" + "," + "" + numberofpassengers + "" + ","+ "" + usersuserid + "" + "," + "" + stationstationid + "" + "," + "" + traintrainnumber + "" + "," + "'" + status + "'" + "," + "'" + passengername + "'" + ")");
            System.out.println("total inserted rows" + number);

            if (numberofpassengers < 0) {

                jsondata.accumulate("STATUS", "WRONG");

                jsondata.accumulate("Message", "Your "
                        + "entered information is wrong");
            } else {
                jsondata.accumulate("STATUS", "OK");

                jsondata.accumulate("Bookingid", bookingid);
                jsondata.accumulate("Message", "Your booking is successfully done");
            }

            stm.close();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            jsondata.accumulate("STATUS", "ERROR");

            jsondata.accumulate("MESSAGE", "Database connectivity error");

        }
        return jsondata.toString();
    }

// GET TRAINS
      
    
    @GET
    @Path("trains")
    @Produces("application/json")
    public String getXml7() throws SQLException {

        long time = System.currentTimeMillis();
        JSONObject SingleStation = new JSONObject();

//        SingleStation.accumulate("Status", "Error");
//        SingleStation.accumulate("EpochTime", time);
//        SingleStation.accumulate("Message", "Station id not exists");
         JSONArray Data = new JSONArray();
        try {
            Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam4", "anypw");
            Statement stm = con.createStatement();

            String sql = "select * from train, station_train where train.trainnumber = station_train.TRAINTRAINNUMBER";
            ResultSet rs = stm.executeQuery(sql);

            int trainnumber, availableseats, station_id;
            String trainname, departurestation, destinationstation, departuretime, destinationtime;
            JSONObject train = new JSONObject();
            SingleStation.accumulate("Status", "Ok");
            SingleStation.accumulate("EpochTime", time);

            
            while (rs.next()) {
//                train.clear();

                


                trainnumber = rs.getInt("TRAINNUMBER");
                availableseats = rs.getInt("AVAILABLESEATS");
                trainname = rs.getString("TRAINNAME");
                departurestation = rs.getString("DEPARTURESTATION");
                destinationstation = rs.getString("DESTINATIONSTATION");
                departuretime = rs.getString("DEPARTURETIME");
                destinationtime = rs.getString("DESTINATIONTIME");
                station_id = rs.getInt("STATIONSTATIONID");
                
                

               
                
                
                train.accumulate("TrainNumber", trainnumber);
                train.accumulate("TrainName", trainname);
                train.accumulate("availableseats", availableseats);
                train.accumulate("departurestation", departurestation);
                train.accumulate("destinationstation", destinationstation);
                train.accumulate("departuretime", departuretime);
                train.accumulate("destinationtime", destinationtime);
                train.accumulate("station_id", station_id);
                
                
                Data.add(train);
                train.clear();

              

            }  rs.close();
                stm.close();
                con.close();
            SingleStation.accumulate("DATA",Data);

        } catch (ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

        return SingleStation.toString();
    }
    
    
    
    
    //update profile
    
    @GET
    @Path("update&{user_id}&{username}&{phone}&{email_id}")
    @Produces("application/json")
    public String getXml8(@PathParam("user_id") int uid,@PathParam("username")String theusername,@PathParam("email_id")String the_email,@PathParam("phone")String thephont) {
        long time = System.currentTimeMillis();
        JSONObject obj = new JSONObject();
            

 
        try {

            Class.forName("oracle.jdbc.OracleDriver");
            Connection con = DriverManager.getConnection("jdbc:oracle:thin:@144.217.163.57:1521:XE", "madteam4", "anypw");
            Statement stm = con.createStatement();
            String sql = "update users set username ='"+theusername+"', email = '"+the_email+"',contactnumber='"+thephont+"' where userid ="+uid;

                        int num = stm.executeUpdate(sql);
            
               
if(num==1){
                    obj.accumulate("Status", "OK");
                    obj.accumulate("Epoch Time", time);
}               
                    

                   
               
            

         //   rs.close();
            stm.close();
            con.close();

        } catch (ClassNotFoundException | SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return obj.toString();

    }
}
